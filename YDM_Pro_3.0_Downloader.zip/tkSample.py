from tkinter import * #Tk, Canvas
from tkinter import ttk

class VerticalScrolledFrame(Frame):
    """A pure Tkinter scrollable frame that actually works!
    * Use the 'interior' attribute to place widgets inside the scrollable frame
    * Construct and pack/place/grid normally
    * This frame only allows vertical scrolling

    """
    def __init__(self, parent, *args, **kw):
        Frame.__init__(self, parent, *args, **kw)            

        # create a canvas object and a vertical scrollbar for scrolling it
        vscrollbar = ttk.Scrollbar(self, orient=VERTICAL)
        vscrollbar.pack(fill=Y, side=RIGHT, expand=FALSE)
        canvas = Canvas(self, bd=0, highlightthickness=0,
                        yscrollcommand=vscrollbar.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=TRUE)
        vscrollbar.config(command=canvas.yview)

        # reset the view
        canvas.xview_moveto(0)
        canvas.yview_moveto(0)

        # create a frame inside the canvas which will be scrolled with it
        self.interior = interior = Frame(canvas)
        interior_id = canvas.create_window(0, 0, window=interior,
                                           anchor=NW)

        # track changes to the canvas and frame width and sync them,
        # also updating the scrollbar
        def _configure_interior(event):
            # update the scrollbars to match the size of the inner frame
            size = (interior.winfo_reqwidth(), interior.winfo_reqheight())
            canvas.config(scrollregion="0 0 %s %s" % size)
            if interior.winfo_reqwidth() != canvas.winfo_width():
                # update the canvas's width to fit the inner frame
                canvas.config(width=interior.winfo_reqwidth())
        interior.bind('<Configure>', _configure_interior)

        def _configure_canvas(event):
            if interior.winfo_reqwidth() != canvas.winfo_width():
                # update the inner frame's width to fill the canvas
                canvas.itemconfigure(interior_id, width=canvas.winfo_width())
        canvas.bind('<Configure>', _configure_canvas)

# http://tkinter.unpythonic.net/wiki/VerticalScrolledFrame
def configure(*args):
	canvas.configure(scrollregion=canvas.bbox("all"),width=50,height=50)

class SampleApp(Tk):
    def __init__(self, *args, **kwargs):
        root = Tk.__init__(self, *args, **kwargs)


        self.frame = VerticalScrolledFrame(root)
        self.frame.pack()
        self.label = Label(text="Shrink the window to activate the scrollbar.")
        self.label.pack()
        buttons = []
        for i in range(10):
            buttons.append(Button(self.frame.interior, text="Button " + str(i)))
            buttons[-1].pack()



def anotherWin(*args):
	app = SampleApp()
	app.mainloop()
	# frame = VerticalScrolledFrame(t)
	# frame.pack()
	# label = Label(text="Shrink the window to activate the scrollbar.")
	# label.pack()

	# downListChecks = []
	# for l in range(10):
	#     iv = IntVar()
	#     iv.set(1)
	#     # iv.trace(callback = printChecks, mode = "w")
	#     downListChecks.append(iv)
	#     c = Checkbutton(frame.interior, text = "Check {}".format(l), variable=iv)
	#     # c.grid(column=0, row=1 + l, sticky=W)
	#     c.pack()


root = Tk()

# Frame 1
mainFrame = ttk.Frame(root)
mainFrame.grid(column=0, row=0, sticky=(N, W, E, S))

b1 = ttk.Button(mainFrame, text = "Click me", command=anotherWin)
b1.grid(column=0, row=0, sticky=E)



root.mainloop()